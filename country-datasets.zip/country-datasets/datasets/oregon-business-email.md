
# Oregon Business Email Dataset

## Overview

This dataset represents a structured collection of professional contact records related to **Oregon Business Email**.

The dataset format is commonly used for:

• market research  
• CRM testing environments  
• analytics experiments  
• structured dataset demonstrations  

## Dataset Fields

First Name  
Last Name  
Company  
Job Title  
Industry  
Email  
Country  

## Sample Dataset

A synthetic sample dataset is included in this repository for research and demonstration purposes.

## Source

Open the dataset documentation:

https://leadsblue.com/leads/usa-state-oregon-business-email-leads-database/
